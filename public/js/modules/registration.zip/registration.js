/**
 * Registration form functionality
 */
(function ($) {
  "use strict";
  const Registration = {
    init: function () {
      const form = $("#flexcore-register-form");
      form.on("submit", this.handleSubmit);
      // Add validation classes on blur
      form.find("input").on("blur", function () {
        if (this.value) {
          $(this).addClass("is-valid").removeClass("has-error");
        }
      });
      // Password confirmation validation
      $("#confirm_password").on("input", this.validatePasswordMatch);
    },
    validatePasswordMatch: function () {
      const password = $("#password").val();
      const confirmPassword = $(this).val();
      if (confirmPassword && password !== confirmPassword) {
        $(this).addClass("has-error").removeClass("is-valid");
        return false;
      } else if (confirmPassword) {
        $(this).addClass("is-valid").removeClass("has-error");
        return true;
      }
    },
   validateFields: function () {
  const messageDiv = $("#register-message");
  const form = $("#flexcore-register-form");
  let isValid = true;

  // Clear previous states
  form.find("input, select, textarea").removeClass("has-error");
  $(".field-error").text("").hide();

  // Check required fields
  form.find("[required]:visible").each(function () {
    const field = $(this);
    const fieldId = field.attr("id");
    const errorDiv = $(`#error-${fieldId}`);

    if (!field.val() || field.val().trim() === "") {
      field.addClass("has-error").removeClass("is-valid");
      const labelText = field.attr("name") || fieldId;
      errorDiv.text(`${labelText} is required.`).show();
      isValid = false;
    }
  });
const name = $("#name").val().trim();
const nameRegex = /^[A-Za-z\s]+$/;

if (!/\S/.test(name)){
 
    $("#name").addClass("has-error").removeClass("is-valid");
  $("#error-name").text("Full name cannot contain only spaces.").show();
  isValid = false;
} else if (name.length < 2) {
 $("#name").addClass("has-error").removeClass("is-valid");
  $("#error-name").text("Full name must be at least 2 characters long.").show();
  isValid = false;
} 
else if (!nameRegex.test(name)) {
  $("#name").addClass("has-error").removeClass("is-valid");
  $("#error-name").text("Full name can only contain letters, spaces.").show();
  isValid = false;
}
else {
  $("#name").addClass("is-valid").removeClass("has-error");
  $("#error-name").hide();
}
  // Email validation
  const email = $("#email").val();
  const confirm_email = $("#confirm_email").val();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailPattern.test(email)) {
    $("#email").addClass("has-error").removeClass("is-valid");
    $("#error-email").text("Invalid email format.").show();
    isValid = false;
  }

  if (email !== confirm_email) {
    $("#confirm_email").addClass("has-error").removeClass("is-valid");
    $("#error-confirm_email").text("Email addresses do not match.").show();
    isValid = false;
  }

  // Password validation
  const password = $("#password").val();
  const confirmPassword = $("#confirm_password").val();

  const passwordErrors = [];
  if (password.length < 12) passwordErrors.push("at least 12 characters");
  if (password.length > 15) passwordErrors.push("at least 15 characters");
  
  if (!/[A-Z]/.test(password)) passwordErrors.push("an uppercase letter");
  if (!/[a-z]/.test(password)) passwordErrors.push("a lowercase letter");
  if (!/[0-9]/.test(password)) passwordErrors.push("a number");
  if (!/[^A-Za-z0-9]/.test(password)) passwordErrors.push("a special character");

  if (passwordErrors.length > 0) {
    $("#password").addClass("has-error").removeClass("is-valid");
    $("#error-password").text("Password must include " + passwordErrors.join(", ") + ".").show();
    isValid = false;
  }

  if (password !== confirmPassword) {
    $("#confirm_password").addClass("has-error").removeClass("is-valid");
    $("#error-confirm_password").text("Passwords do not match.").show();
    isValid = false;
  }

  // Consent checkbox
  if (!$("#consent").is(":checked")) {
    messageDiv
      .removeClass("success")
      .addClass("error")
      .html("You must agree to the terms and conditions.")
      .show();
    isValid = false;
  } else {
    messageDiv.hide();
  }

  return isValid;
},


    handleSubmit: function (e) {
      e.preventDefault();
      const form = $(this);
      const submitBtn = form.find('button[type="submit"]');
      const messageDiv = $("#register-message");
      // Validate fields before submission
      if (!Registration.validateFields()) {
        return;
      }
      submitBtn.prop("disabled", true).addClass("loading");
      messageDiv.hide();
      $.ajax({
        url: flexcoreServerAjax.ajaxUrl,
        type: "POST",
        data: {
          action: "flexcore_register",
          register_nonce: $("#register_nonce").val(),

          email: $("#email").val(),
          name: $("#name").val(),
          password: $("#password").val(),
          referral_code: $("#referral_code").val() || "",
          utm_string: $("#utm_string").val() || "",
          campaign_id: $("#campaign_id").val() || "",
          register_source: $("#register_source").val() || "",
        },
        success: function (response) {
          if (response.success) {
            messageDiv
              .removeClass("error")
              .addClass("success")
              .html(response.data.message)
              .show();
            if (response.data.redirect) {
              window.location.href = response.data.redirect;
            }
          } else {
            messageDiv
              .removeClass("success")
              .addClass("error")
              .html(
                response.data.message ||
                  flexcoreServerAjax.i18n.registrationFailed
              )
              .show();
          }
        },
        error: function () {
          messageDiv
            .removeClass("success")
            .addClass("error")
            .html(flexcoreServerAjax.i18n.errorOccurred)
            .show();
        },
        complete: function () {
          submitBtn.prop("disabled", false).removeClass("loading");
        },
      });
    },
  };
  // Initialize when document is ready
  $(document).ready(function () {
    Registration.init();
  });
})(jQuery);
